data class PRODUTO(
    val id_produto: Int,
    val nome_produto: String,
    val desc_produto: String,
    val preco_produto: String,
    val numero_celular String,
    val imagem_produto: String
)
